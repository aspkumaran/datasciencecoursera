package com.candidjava;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.candidjava.spring.service.UserService;

public class JobCreation implements Job{
	
	private static Logger log = LoggerFactory.getLogger(SchedulingQuartz.class);

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		UserService userService;
		try {
			userService = (UserService) context.getScheduler().getContext().get("userService");
			log.info("User Service List :"+userService.getUser());
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
