<?php
error_log("Logging beacon request");
    error_log(print_r($_REQUEST, true));
    echo("In Beacon.php");
	exit;
?>
