package com.candidjava;

import static org.quartz.DateBuilder.futureDate;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.SimpleScheduleBuilder.simpleSchedule;
import static org.quartz.TriggerBuilder.newTrigger;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.quartz.DateBuilder.IntervalUnit;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleTrigger;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.candidjava.spring.service.UserService;

@Service
public class SchedulingQuartz {
	
	private static Logger _log = LoggerFactory.getLogger(SchedulingQuartz.class);
	@Autowired
	private UserService userService;
	@Autowired
	private SampleMail sampleMail;
	Scheduler sched;
      @PostConstruct
	  public void ScheduleTask() throws Exception {

	    // First we must get a reference to a scheduler
	    SchedulerFactory sf = new StdSchedulerFactory();
	    sched = sf.getScheduler();
	    
	    sched.clear();
	    
        String schedId = sched.getSchedulerInstanceId();
        
        sched.getContext().put("userService", userService);
        sched.getContext().put("sampleMail", sampleMail);

	      JobDetail job = newJob(JobCreation.class).withIdentity("job", schedId) // put triggers in group
	                                                                                            // named after the cluster
	                                                                                            // node instance just to
	                                                                                            // distinguish (in logging)
	                                                                                            // what was scheduled from
	                                                                                            // where
	          .requestRecovery() // ask scheduler to re-execute this job if it was in progress when the scheduler went
	                             // down...
	          .build();

	      SimpleTrigger trigger = newTrigger().withIdentity("triger_", schedId)
	          .startAt(futureDate(5, IntervalUnit.SECOND))
	          .withSchedule(simpleSchedule().withRepeatCount(20).withIntervalInSeconds(5)).build();

	      _log.info(job.getKey() + " will run at: " + trigger.getNextFireTime() + " and repeat: "
	                + trigger.getRepeatCount() + " times, every " + trigger.getRepeatInterval() / 1000 + " seconds");
	      sched.scheduleJob(job, trigger);
	      sched.start();
	    }
      
      @PreDestroy
      void destroyCode() throws SchedulerException {
    	  _log.info("Shutting down the scheduler");
    	  sched.shutdown();
      }
}
