package com.candidjava;

import java.util.List;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.candidjava.spring.bean.User;
import com.candidjava.spring.service.UserService;

public class JobCreation implements Job{
	
	private static Logger log = LoggerFactory.getLogger(SchedulingQuartz.class);

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		UserService userService;
		SampleMail sampleMail;
		try {
			userService = (UserService) context.getScheduler().getContext().get("userService");
			log.info("User Service List :"+userService.getUser());
			sampleMail = (SampleMail) context.getScheduler().getContext().get("sampleMail");
			StringBuilder sb = new StringBuilder();
			List<User> userlist = userService.getUser();
			for(int i=0;i<userlist.size();i++) {
				sb.append(userlist.get(i));	
			}
			sampleMail.mailservice(sb+"");
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
