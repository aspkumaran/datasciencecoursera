package com.candidjava;

import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Service;

@Service
public class SampleMail {
    private Session session;
    
    @PostConstruct
	private void PostConstruct(){
		   Properties props = new Properties();
		   props.put("mail.smtp.auth", "true");
		   props.put("mail.smtp.starttls.enable", "true");
		   props.put("mail.smtp.host", "smtp.gmail.com");
		   props.put("mail.smtp.port", "587");
		   props.put("mail.smtp.starttls.required", "true");
		   session = Session.getInstance(props, new javax.mail.Authenticator(){
		        protected PasswordAuthentication getPasswordAuthentication() {
		            return new PasswordAuthentication(
		                "xxxxxx@xxxx.xxx", "xxxxxx");// Specify the Username and the PassWord
		        }
		});
    }
    
    public void mailservice(String emess) {
    	   try {
    	 	MimeMessage msg = new MimeMessage(session);
		msg.setFrom(new InternetAddress("invinhacker@gmail.com", false));
        msg.setRecipients(Message.RecipientType.TO,
        		InternetAddress.parse("aspkumaran@gmail.com"));
		msg.setSubject("Test email");
		msg.setText(emess);
        Transport.send(msg);   
	}catch(MessagingException e) {
		throw new RuntimeException(e);
	}
	}
	
}
