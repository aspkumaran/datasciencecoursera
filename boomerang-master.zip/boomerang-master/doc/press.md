#### Articles Talking about Boomerang!

This is a list of articles (that we are aware of) that speak about boomerang.  If you write one,
or know of one that isn't here, let us know, and we'll add it.

* June 24, 2010 &mdash; <a href="http://developer.yahoo.net/blog/archives/2010/06/performance_testing_with_boomerang.html">Performance testing with boomerang</a> at YDN
* June 24, 2010 &mdash; <a href="http://www.readwriteweb.com/archives/yahoo_lets_loose_with_a_boomerang_-_automatic_webs.php">Yahoo! Lets Loose With a Boomerang</a> at ReadWriteWeb
* June 30, 2010 &mdash; <a href="http://dailyjs.com/2010/06/30/site-performance-with-boomerang/">Measuring Performance with Boomerang</a> at DailyJS
* July 1, 2010 &mdash; <a href="http://www.dinero20.com/2010/07/01/boomerang-la-nueva-iniciativa-de-yahoo/">Boomerang la nueva iniciativa de Yahoo!</a> at Dinero 2.0
* July 5, 2010 &mdash; <a href="http://www.kikabink.com/news/yahoos-boomerang-tells-you-how-long-your-web-pages-load/">Yahoo's Boomerang Tells You How Long Your Web Pages Load</a> at Kikabink News
* July 19, 2010 &mdash; <a href="http://www.facebook.com/note.php?note_id=408327833919">Internet Cartography</a> at Facebook Engineering
* July 22, 2010 &mdash; <a href="http://thenextweb.com/apps/2010/07/22/boomerang-an-incredibly-useful-tool-to-help-you-investigate-site-speed/">Boomerang: An incredibly useful tool from Yahoo! to help you investigate site speed</a> at The Next Web
* July 22, 2010 &mdash; <a href="http://radar.oreilly.com/2010/07/four-short-links-22-july-2010.html">Four short links: 22 July 2010</a> on O'Reilly Radar
* July 26, 2010 &mdash; <a href="http://www.webperformancetoday.com/2010/07/26/yahoos-new-applet-promises-real-world-end-user-performance-reporting/">Yahoo's new applet promises real-world end-user performance reporting</a> on Web Performance Today
* July 28, 2010 &mdash; <a href="http://developer.yahoo.net/blog/archives/2010/07/boomerang_webtiming_api.html">Boomerang and the WebTiming API</a> at YDN
* July 31, 2010 &mdash; <a href="http://loquenecesita.com/2010/07/boomerang-analiza-el-redimiento-de-un-sitio-web-en-el-lado-del-cliente/">Boomerang: Analiza el redimiento de un sitio Web en el lado del cliente</a> at Loque Necesita
* August 13, 2010 &mdash; <a href="http://www.sitepoint.com/blogs/2010/08/13/boomerang-user-web-performance-testing/">Performance Testing Comes Back With Boomerang</a> at SitePoint
* August 23, 2010 &mdash; <a href="http://razorfast.com/2010/08/23/monitoring-your-sites-performance-using-boomerang/">Monitoring your site's performance using boomerang</a> at Razor Fast
