/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/09-backbone/22-config-after-onload", function() {
	BOOMR_test.templates.SPA["22-config-after-onload"]();
});
