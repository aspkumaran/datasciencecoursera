/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/08-ember/25-delayed-boomerang-pre-config-snippet", function() {
	BOOMR_test.templates.SPA["25-delayed-boomerang-pre-config-snippet"]();
});
