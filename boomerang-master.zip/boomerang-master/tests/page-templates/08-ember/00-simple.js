/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/08-ember/00-simple", function() {
	BOOMR_test.templates.SPA["00-simple"]();
});
