/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/08-ember/24-route-filter", function() {
	BOOMR_test.templates.SPA["24-route-filter"]();
});
