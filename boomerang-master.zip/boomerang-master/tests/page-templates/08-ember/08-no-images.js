/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/08-ember/08-no-images", function() {
	BOOMR_test.templates.SPA["08-no-images"]();
});
