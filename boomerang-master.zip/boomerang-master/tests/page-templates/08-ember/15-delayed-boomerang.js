/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/08-ember/15-delayed-boomerang", function() {
	BOOMR_test.templates.SPA["15-delayed-boomerang"]();
});
