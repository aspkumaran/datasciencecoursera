/*eslint-env mocha*/
describe("e2e/08-ember/23-hard-wait-for-onload", function() {
	BOOMR_test.templates.SPA["23-hard-wait-for-onload"]();
});
