/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/08-ember/07-soft-nav-resources", function() {
	BOOMR_test.templates.SPA["07-soft-nav-resources"]();
});
