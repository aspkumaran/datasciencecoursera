/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/09-backbone/16-autoxhr-after-load-with-mutation", function() {
	BOOMR_test.templates.SPA["16-autoxhr-after-load-with-mutation"]();
});
