/*eslint-env mocha*/
/*global BOOMR_test*/
describe("e2e/09-backbone/19-autoxhr-during-nav-alwayssendxhr", function() {
	BOOMR_test.templates.SPA["19-autoxhr-during-nav-alwayssendxhr"]();
});
