/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/09-backbone/17-wait", function() {
	BOOMR_test.templates.SPA["17-wait"]();
});
