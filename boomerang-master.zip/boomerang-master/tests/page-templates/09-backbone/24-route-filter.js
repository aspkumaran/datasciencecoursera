/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/09-backbone/24-route-filter", function() {
	BOOMR_test.templates.SPA["24-route-filter"]();
});
