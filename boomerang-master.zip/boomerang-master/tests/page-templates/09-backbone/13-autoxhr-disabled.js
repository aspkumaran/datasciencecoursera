/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/09-backbone/13-autoxhr-disabled", function() {
	BOOMR_test.templates.SPA["13-autoxhr-disabled"]();
});
