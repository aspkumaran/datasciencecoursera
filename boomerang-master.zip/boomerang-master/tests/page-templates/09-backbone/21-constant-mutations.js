/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/09-backbone/21-constant-mutations", function() {
	BOOMR_test.templates.SPA["21-constant-mutations"]();
});
