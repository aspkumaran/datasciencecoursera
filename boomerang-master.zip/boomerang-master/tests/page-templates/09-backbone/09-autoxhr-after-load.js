/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/09-backbone/09-autoxhr-after-load", function() {
	BOOMR_test.templates.SPA["09-autoxhr-after-load"]();
});
