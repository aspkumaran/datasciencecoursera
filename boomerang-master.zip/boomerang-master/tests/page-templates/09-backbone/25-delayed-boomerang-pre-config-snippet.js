/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/09-backbone/25-delayed-boomerang-pre-config-snippet", function() {
	BOOMR_test.templates.SPA["25-delayed-boomerang-pre-config-snippet"]();
});
