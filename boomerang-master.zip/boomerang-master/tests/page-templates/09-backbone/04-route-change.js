/*eslint-env mocha*/
describe("e2e/05-backbone/04-route-change", function() {
	BOOMR_test.templates.SPA["04-route-change"]();
});
