/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/09-backbone/08-no-images", function() {
	BOOMR_test.templates.SPA["08-no-images"]();
});
