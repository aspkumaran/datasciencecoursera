/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/09-backbone/11-autoxhr-trigger-additional", function() {
	BOOMR_test.templates.SPA["11-autoxhr-trigger-additional"]();
});
