/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/09-backbone/05-route-change-hashtags", function() {
	BOOMR_test.templates.SPA["05-route-change-hashtags"]();
});
