/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/05-angular/20-no-resources", function() {
	BOOMR_test.templates.SPA["20-no-resources"]();
});
