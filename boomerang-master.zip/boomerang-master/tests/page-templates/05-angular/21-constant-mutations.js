/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/05-angular/21-constant-mutations", function() {
	BOOMR_test.templates.SPA["21-constant-mutations"]();
});
