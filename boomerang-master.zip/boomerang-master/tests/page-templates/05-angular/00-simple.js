/*eslint-env mocha*/
/*
* This app uses a delayed angular.bootstrap (and no ng-app)
* directive.
*/
describe("e2e/05-angular/00-simple", function() {
	BOOMR_test.templates.SPA["00-simple"]();
});
