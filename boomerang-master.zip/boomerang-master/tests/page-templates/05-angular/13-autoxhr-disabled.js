/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/05-angular/13-autoxhr-disabled", function() {
	BOOMR_test.templates.SPA["13-autoxhr-disabled"]();
});
