/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/17-wait", function() {
	BOOMR_test.templates.SPA["17-wait"]();
});
