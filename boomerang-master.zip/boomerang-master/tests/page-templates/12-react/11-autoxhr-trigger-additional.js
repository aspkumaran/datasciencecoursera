/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/11-trigger-additional", function() {
	BOOMR_test.templates.SPA["11-autoxhr-trigger-additional"]();
});
