/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/06-hard-nav-resources", function() {
	BOOMR_test.templates.SPA["06-hard-nav-resources"]();
});
