/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/07-soft-nav-resources", function() {
	BOOMR_test.templates.SPA["07-soft-nav-resources"]();
});
