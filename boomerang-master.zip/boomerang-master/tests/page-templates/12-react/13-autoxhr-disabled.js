/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/13-autoxhr-disabled", function() {
	BOOMR_test.templates.SPA["13-autoxhr-disabled"]();
});
