/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/15-delayed-boomerang", function() {
	BOOMR_test.templates.SPA["15-delayed-boomerang"]();
});
