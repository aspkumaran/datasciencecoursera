/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/08-no-images", function() {
	BOOMR_test.templates.SPA["08-no-images"]();
});
