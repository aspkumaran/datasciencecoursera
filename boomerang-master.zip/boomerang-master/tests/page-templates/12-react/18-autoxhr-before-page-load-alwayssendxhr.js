/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/18-autoxhr-before-page-load-alwayssendxhr", function() {
	BOOMR_test.templates.SPA["18-autoxhr-before-page-load-alwayssendxhr"]();
});
