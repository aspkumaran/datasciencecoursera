/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/12-autoxhr-trigger-additional-after-delay", function() {
	BOOMR_test.templates.SPA["12-autoxhr-trigger-additional-after-delay"]();
});
