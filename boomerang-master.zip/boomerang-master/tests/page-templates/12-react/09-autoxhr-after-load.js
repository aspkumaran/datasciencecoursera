/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/09-autoxhr-after-load", function() {
	BOOMR_test.templates.SPA["09-autoxhr-after-load"]();
});
