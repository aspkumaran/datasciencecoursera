/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/14-autoxhr-before-page-load", function() {
	BOOMR_test.templates.SPA["14-autoxhr-before-page-load"]();
});
