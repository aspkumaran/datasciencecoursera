/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/20-no-resources", function() {
	BOOMR_test.templates.SPA["20-no-resources"]();
});
