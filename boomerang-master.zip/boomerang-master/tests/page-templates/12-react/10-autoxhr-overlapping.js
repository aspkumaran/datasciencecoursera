/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/10-autoxhr-overlapping", function() {
	BOOMR_test.templates.SPA["10-autoxhr-overlapping"]();
});
