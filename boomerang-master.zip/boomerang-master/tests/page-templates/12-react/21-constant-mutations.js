/*eslint-env mocha*/
/*global BOOMR_test*/

describe("e2e/12-react/21-constant-mutations", function() {
	BOOMR_test.templates.SPA["21-constant-mutations"]();
});
