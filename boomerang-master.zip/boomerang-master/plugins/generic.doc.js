/**
 * @memberof Boomerang
 * @typedef TimeStamp
 * @type {number}
 *
 * @desc
 * A timestamp created by [BOOMR.now()]{@link BOOMR#now}
 */
