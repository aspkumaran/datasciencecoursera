BOOMR.t_end = new Date().getTime();
